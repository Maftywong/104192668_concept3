document.addEventListener("DOMContentLoaded", function () {
    $.ajax({
        url: '/api/user_dashboard',  // Modify to use the Flask endpoint
        type: 'GET',
        success: function (response) {
            // Assuming response is a JSON object containing malware type counts
            var data = JSON.parse(response);

            // Convert data to the format needed by ECharts
            var chartData = [];
            for (var key in data) {
                chartData.push({ value: data[key], name: key });
            }

            // Initialize Pie Chart
            var pieChart = echarts.init(document.getElementById('user-pie-chart'));
            var pieOption = {
                title: {
                    text: 'User-Specific Malware Detection',
                    left: 'center'
                },
                tooltip: {
                    trigger: 'item'
                },
                legend: {
                    orient: 'vertical',
                    left: 'left'
                },
                series: [
                    {
                        name: 'Malware Types',
                        type: 'pie',
                        radius: '50%',
                        data: chartData,
                        emphasis: {
                            itemStyle: {
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(0, 0, 0, 0.5)'
                            }
                        }
                    }
                ]
            };
            pieChart.setOption(pieOption);

            // Initialize Bar Chart (Optional - similar logic)
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log('Error fetching chart data: ' + textStatus);
        }
    });
});
