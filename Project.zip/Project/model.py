from flask import Flask, request, jsonify, render_template
import pandas as pd
import joblib
import numpy as np

app = Flask(__name__)

# Load models
rf_model = joblib.load('random_forest_model.joblib')
gb_model = joblib.load('gradient_boosting_model.joblib')
scaler = joblib.load('scaler.joblib')
label_encoder = joblib.load('label_encoder.joblib')

@app.route('/')
def index():
    return render_template('upload.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Check if a file is uploaded
        if 'file' not in request.files:
            return "No file uploaded", 400
        
        file = request.files['file']
        
        if file.filename == '':
            return "No file selected", 400
        
        # Read the CSV file and ensure the data is numeric
        df = pd.read_csv(file)
        if df.shape[1] != 160:  # Adjust based on expected features
            return "Incorrect number of features in CSV", 400
        
        # Preprocess the data with the scaler
        scaled_data = scaler.transform(df.values)
        
        # Make predictions using both models
        rf_predictions = rf_model.predict(scaled_data)
        gb_predictions = gb_model.predict(scaled_data)
        
        # Convert predictions back to the original labels
        rf_labels = label_encoder.inverse_transform(rf_predictions)
        gb_labels = label_encoder.inverse_transform(gb_predictions)
        
        # Prepare results
        results = {
            "rf_predictions": rf_labels.tolist(),
            "gb_predictions": gb_labels.tolist()
        }
        
        # Return the results as JSON (or you can render a template to visualize it)
        return jsonify(results)
    
    except Exception as e:
        print(f"Error: {e}")
        return "An error occurred during prediction", 500

if __name__ == '__main__':
    app.run(debug=True)
