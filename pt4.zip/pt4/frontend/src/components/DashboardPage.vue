<template>
  <div>
    <h2>Welcome to the Dashboard Page</h2>
    <file-upload @analysis-completed="handleAnalysisResults"></file-upload>
    <div v-if="results">
      <h3>Binary Classification</h3>
      <div ref="binaryChart" style="width: 600px; height: 400px;"></div>

      <h3>Multi-Class Classification</h3>
      <div ref="multiClassChart" style="width: 600px; height: 400px;"></div>
    </div>
  </div>
</template>

<script>
import * as echarts from 'echarts';
import FileUpload from './FileUpload.vue';

export default {
  name: 'DashboardPage',
  components: {
    FileUpload,
  },
  data() {
    return {
      results: null,
    };
  },
  methods: {
    handleAnalysisResults(results) {
      this.results = results;
      this.renderBinaryChart(results.binary_classification);
      this.renderMultiClassChart(results.multi_class_classification);
    },
    renderBinaryChart(binaryResult) {
      const chart = echarts.init(this.$refs.binaryChart);
      const option = {
        title: {
          text: 'Binary Classification Result',
        },
        tooltip: {
          trigger: 'item',
        },
        series: [
          {
            name: 'Classification',
            type: 'pie',
            data: [
              { value: binaryResult.probability, name: 'Malicious' },
              { value: 1 - binaryResult.probability, name: 'Benign' },
            ],
          },
        ],
      };
      chart.setOption(option);
    },
    renderMultiClassChart(multiClassResult) {
      const chart = echarts.init(this.$refs.multiClassChart);
      const option = {
        title: {
          text: 'Multi-Class Classification Probabilities',
        },
        tooltip: {
          trigger: 'axis',
        },
        xAxis: {
          type: 'category',
          data: multiClassResult.all_probabilities.map((item) => item.class),
        },
        yAxis: {
          type: 'value',
        },
        series: [
          {
            data: multiClassResult.all_probabilities.map((item) => item.probability),
            type: 'bar',
          },
        ],
      };
      chart.setOption(option);
    },
  },
};
</script>

<style scoped>
h3 {
  margin-top: 2rem;
}
</style>
