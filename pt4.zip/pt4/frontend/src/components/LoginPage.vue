<template>
  <div>
    <h2>Login</h2>
    <div>
      <label>Username:</label>
      <input v-model="username" type="text" />
    </div>
    <div>
      <label>Password:</label>
      <input v-model="password" type="password" />
    </div>
    <button @click="login">Login</button>
  </div>
</template>

<script>
import axios from 'axios';
import config from '@/api/config';

export default {
  name: 'LoginPage',
  data() {
    return {
      username: '',
      password: '',
    };
  },
  methods: {
    async login() {
      try {
        const response = await axios.post(`${config.baseUrl}/api/login`, {
          username: this.username,
          password: this.password,
        });
        if (response.data.success) {
          localStorage.setItem('token', response.data.token);
          localStorage.setItem('username', this.username); // Store username in localStorage
          this.$router.push('/dashboard');
        } else {
          alert('Invalid username or password');
        }
      } catch (error) {
        console.error(error);
        alert('An error occurred during login. Please try again.');
      }
    },
  },
};
</script>

<style scoped>
/* Add any styles needed for your login page */
</style>