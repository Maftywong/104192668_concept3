<template>
  <div>
    <input type="file" @change="handleFileUpload" />
    <button @click="analyzeFile">Analyze</button>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'FileUpload',
  data() {
    return {
      selectedFile: null,
    };
  },
  methods: {
    handleFileUpload(event) {
      this.selectedFile = event.target.files[0];
    },
    async analyzeFile() {
      if (!this.selectedFile) {
        alert('Please select a file first.');
        return;
      }

      try {
        const token = localStorage.getItem('token');
        const formData = new FormData();
        formData.append('file', this.selectedFile);

        const response = await axios.post('/api/analyze', formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${token}`,
          },
        });

        if (response.data) {
          this.$emit('analysis-completed', response.data.results);
        } else {
          alert('Analysis failed. Please try again.');
        }
      } catch (error) {
        console.error('Error analyzing file:', error);
        alert('Analysis failed. Please try again.');
      }
    },
  },
};
</script>
