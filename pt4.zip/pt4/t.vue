### LoginPage.vue (Updated Code)
```vue
<template>
  <div>
    <h2>Login</h2>
    <div>
      <label>Username:</label>
      <input v-model="username" type="text" />
    </div>
    <div>
      <label>Password:</label>
      <input v-model="password" type="password" />
    </div>
    <button @click="login">Login</button>
  </div>
</template>

<script>
import axios from 'axios';
import config from '@/api/config';

export default {
  name: 'LoginPage',
  data() {
    return {
      username: '',
      password: '',
    };
  },
  methods: {
    async login() {
      try {
        const response = await axios.post(`${config.baseUrl}/api/login`, {
          username: this.username,
          password: this.password,
        });
        if (response.data.success) {
          localStorage.setItem('token', response.data.token);
          localStorage.setItem('username', this.username); // Store username in localStorage
          this.$router.push('/dashboard');
        } else {
          alert('Invalid username or password');
        }
      } catch (error) {
        console.error(error);
        alert('An error occurred during login. Please try again.');
      }
    },
  },
};
</script>

<style scoped>
/* Add any styles needed for your login page */
</style>
```

### DashboardPage.vue (Updated Code)
```vue
<template>
  <div>
    <h2>Welcome to the Dashboard Page</h2>
    <div v-if="username">
      <p>Logged in as: {{ username }}</p>
    </div>
    <file-upload @analysis-completed="handleAnalysisResults"></file-upload>
    <div v-if="results">
      <h3>Binary Classification</h3>
      <div ref="binaryChart" class="chart-container"></div>

      <h3>Multi-Class Classification</h3>
      <div ref="multiClassChart" class="chart-container"></div>
    </div>
  </div>
</template>

<script>
import * as echarts from 'echarts';
import FileUpload from './FileUpload.vue';
import '@/assets/dashboard.css'; // Import external CSS file

export default {
  name: 'DashboardPage',
  components: {
    FileUpload,
  },
  data() {
    return {
      results: null,
      username: '',
    };
  },
  created() {
    // Retrieve the username from localStorage
    this.username = localStorage.getItem('username') || 'Unknown User';
  },
  methods: {
    handleAnalysisResults(results) {
      this.results = results;
      this.renderBinaryChart(results.binary_classification);
      this.renderMultiClassChart(results.multi_class_classification);
    },
    renderBinaryChart(binaryResult) {
      const chart = echarts.init(this.$refs.binaryChart);
      const option = {
        title: {
          text: 'Binary Classification Result',
        },
        tooltip: {
          trigger: 'item',
        },
        series: [
          {
            name: 'Classification',
            type: 'pie',
            data: [
              { value: binaryResult.probability, name: 'Malicious' },
              { value: 1 - binaryResult.probability, name: 'Benign' },
            ],
          },
        ],
      };
      chart.setOption(option);
    },
    renderMultiClassChart(multiClassResult) {
      const chart = echarts.init(this.$refs.multiClassChart);
      const option = {
        title: {
          text: 'Multi-Class Classification Probabilities',
        },
        tooltip: {
          trigger: 'axis',
        },
        xAxis: {
          type: 'category',
          data: multiClassResult.all_probabilities.map((item) => item.class),
        },
        yAxis: {
          type: 'value',
        },
        series: [
          {
            data: multiClassResult.all_probabilities.map((item) => item.probability),
            type: 'bar',
          },
        ],
      };
      chart.setOption(option);
    },
  },
};
</script>

<style scoped>
h2 {
  margin-top: 1rem;
  text-align: center;
}

h3 {
  margin-top: 2rem;
  text-align: center;
}

p {
  font-weight: bold;
  margin-bottom: 1rem;
  text-align: center;
}

.chart-container {
  margin: 0 auto;
  width: 600px;
  height: 400px;
}
</style>