import json
from flask.json import jsonify
from flask import Flask, request, jsonify
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
from sklearn.preprocessing import OneHotEncoder
from flask_cors import CORS
import numpy as np
import pandas as pd
import joblib
from datetime import datetime, timedelta
import os
import logging
from logging.handlers import RotatingFileHandler
 
app = Flask(__name__)
CORS(app)  # Enable CORS for all domains on all routes
 
# Configuration
app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET_KEY', '853fc6e8a7ad1a5c89a90571e4d0c24d8ed61f1c4d4efc3503f6d39c9e18fb26')  # Use environment variable
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///malware_analysis.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=1)  # Set token expiration
 
jwt = JWTManager(app)
db = SQLAlchemy(app)
 
# Setup logging
handler = RotatingFileHandler('app.log', maxBytes=10000, backupCount=1)
handler.setLevel(logging.INFO)
app.logger.addHandler(handler)
app.logger.setLevel(logging.INFO)
 
# Define database models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
 
class UploadedFile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(120), nullable=False)
    upload_date = db.Column(db.DateTime, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
 
class AnalysisResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    file_id = db.Column(db.Integer, db.ForeignKey('uploaded_file.id'), nullable=False)
    binary_class = db.Column(db.String(20), nullable=False)
    multi_class = db.Column(db.String(20), nullable=False)
    binary_probability = db.Column(db.Float, nullable=False)
    multi_class_probabilities = db.Column(db.String(200), nullable=False)  # Store as JSON string
 
# Load models
try:
    binary_rf_model = joblib.load('/Users/richtofen/Documents/MA-IT/MA-IT24S2/COS70008/pt4/backend/models/saved_model_binary/random_forest_model.joblib')
    binary_gb_model = joblib.load('/Users/richtofen/Documents/MA-IT/MA-IT24S2/COS70008/pt4/backend/models/saved_model_binary/gradient_boosting_model.joblib')
    binary_scaler = joblib.load('/Users/richtofen/Documents/MA-IT/MA-IT24S2/COS70008/pt4/backend/models/saved_model_binary/scaler.joblib')
    binary_label_encoder = joblib.load('/Users/richtofen/Documents/MA-IT/MA-IT24S2/COS70008/pt4/backend/models/saved_model_binary/label_encoder.joblib')
    binary_selected_features = joblib.load('/Users/richtofen/Documents/MA-IT/MA-IT24S2/COS70008/pt4/backend/models/saved_model_binary/selected_features.joblib')
 
    multi_rf_model = joblib.load('/Users/richtofen/Documents/MA-IT/MA-IT24S2/COS70008/pt4/backend/models/saved_model_multiclass/random_forest_model.joblib')
    multi_gb_model = joblib.load('/Users/richtofen/Documents/MA-IT/MA-IT24S2/COS70008/pt4/backend/models/saved_model_multiclass/gradient_boosting_model.joblib')
    multi_scaler = joblib.load('/Users/richtofen/Documents/MA-IT/MA-IT24S2/COS70008/pt4/backend/models/saved_model_multiclass/scaler.joblib')
    multi_label_encoder = joblib.load('/Users/richtofen/Documents/MA-IT/MA-IT24S2/COS70008/pt4/backend/models/saved_model_multiclass/label_encoder.joblib')
    multi_selected_features = joblib.load('/Users/richtofen/Documents/MA-IT/MA-IT24S2/COS70008/pt4/backend/models/saved_model_multiclass/selected_features.joblib')
 
    print("Binary selected features:", binary_selected_features)
    print("Multiclass selected features:", multi_selected_features)
except Exception as e:
    app.logger.error(f"Error loading models: {str(e)}")
    raise
 
@app.route('/')
def home():
    return jsonify({"message": "Welcome to the Malware Analysis Tool API", "version": "1.0"})
 
@app.route('/api/login', methods=['POST'])
def login():
    username = request.json.get('username', None)
    password = request.json.get('password', None)
   
    if not username or not password:
        return jsonify({"msg": "Missing username or password"}), 400
 
    user = User.query.filter_by(username=username).first()
    if user and check_password_hash(user.password, password):
        access_token = create_access_token(identity=username)
        app.logger.info(f"User {username} logged in successfully")
        return jsonify(success=True, token=access_token, isAdmin=user.is_admin)
    else:
        app.logger.warning(f"Failed login attempt for username: {username}")
        return jsonify({"msg": "Bad username or password"}), 401
 
 
def validate_csv(df):
    expected_columns = set(binary_scaler.feature_names_in_)
    actual_columns = set(df.columns)
   
    missing_columns = expected_columns - actual_columns
    extra_columns = actual_columns - expected_columns
   
    if missing_columns or extra_columns:
        error_msg = "CSV file does not match the expected format.\n"
        if missing_columns:
            error_msg += f"Missing columns: {', '.join(missing_columns)}\n"
        if extra_columns:
            error_msg += f"Extra columns: {', '.join(extra_columns)}\n"
        raise ValueError(error_msg)
   
def preprocess_input_data(df, selected_features):
    # Ensure all selected features are present in the input data
    for feature in selected_features:
        if feature not in df.columns:
            df[feature] = 0  # or any appropriate default value
 
    # Select only the selected features in the correct order
    preprocessed_df = df[selected_features]
 
    return preprocessed_df
 
 
class NumpyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        return super(NumpyEncoder, self).default(obj)
 
@app.route('/api/analyze', methods=['POST'])
@jwt_required()
def analyze_files():
    current_user = get_jwt_identity()
    app.logger.info(f"User {current_user} accessed /api/analyze endpoint")
   
    if 'file' not in request.files:
        app.logger.warning("No file part in the request")
        return jsonify({'error': 'No file part'}), 400
   
    file = request.files['file']
    if file.filename == '':
        app.logger.warning("No selected file")
        return jsonify({'error': 'No selected file'}), 400
   
    if not file.filename.endswith('.csv'):
        app.logger.warning(f"Invalid file type: {file.filename}")
        return jsonify({'error': 'Invalid file type. Only CSV files are allowed.'}), 400
   
    try:
        df = pd.read_csv(file)
        app.logger.info(f"CSV file read successfully. Shape: {df.shape}")
        print("Input CSV columns:", df.columns)
 
        # Preprocess the input data for binary classification
        binary_features = preprocess_input_data(df, binary_selected_features)
        app.logger.info(f"Data preprocessed for binary classification. Shape: {binary_features.shape}")
        print("Binary preprocessed columns:", binary_features.columns)
 
        # Preprocess the input data for multiclass classification
        multi_features = preprocess_input_data(df, multi_selected_features)
        app.logger.info(f"Data preprocessed for multiclass classification. Shape: {multi_features.shape}")
        print("Multiclass preprocessed columns:", multi_features.columns)
 
        # Binary classification
        binary_rf_pred = binary_rf_model.predict_proba(binary_features)
        binary_gb_pred = binary_gb_model.predict_proba(binary_features)
        binary_pred_proba = (binary_rf_pred + binary_gb_pred) / 2
        binary_pred = (binary_pred_proba[:, 1] > 0.5).astype(int)
 
        # Multi-class classification
        multi_rf_pred = multi_rf_model.predict_proba(multi_features)
        multi_gb_pred = multi_gb_model.predict_proba(multi_features)
        multi_pred_proba = (multi_rf_pred + multi_gb_pred) / 2
        multi_pred = np.argmax(multi_pred_proba, axis=1)
 
        # Decode predictions
        binary_labels = binary_label_encoder.inverse_transform(binary_pred)
        multi_labels = multi_label_encoder.inverse_transform(multi_pred)
 
        # Save results to database
        uploaded_file = UploadedFile(filename=file.filename, upload_date=datetime.utcnow(), user_id=current_user)
        db.session.add(uploaded_file)
        db.session.flush()
       
        for i in range(len(binary_pred)):
            result = AnalysisResult(
                file_id=uploaded_file.id,
                binary_class=binary_labels[i],
                multi_class=multi_labels[i],
                binary_probability=float(binary_pred_proba[i, 1]),
                multi_class_probabilities=','.join(map(str, multi_pred_proba[i]))
            )
            db.session.add(result)
       
        db.session.commit()
 
        # Get the class names from the multi-class label encoder
        class_names = multi_label_encoder.classes_
 
        # Create a sorted list of (class_name, probability) tuples
        multi_class_probs = sorted(
            zip(class_names, multi_pred_proba[0]),
            key=lambda x: x[1],
            reverse=True
        )
 
        response_data = {
            'message': 'File analyzed successfully',
            'results': {
                'binary_classification': {
                    'class': 'Malicious' if binary_pred[0] == 1 else 'Benign',
                    'probability': round(float(binary_pred_proba[0, 1]), 4)
                },
                'multi_class_classification': {
                    'top_class': multi_labels[0],
                    'top_probability': round(float(np.max(multi_pred_proba[0])), 4),
                    'all_probabilities': [
                        {'class': class_name, 'probability': round(float(prob), 4)}
                        for class_name, prob in multi_class_probs
                    ]
                }
            }
        }
 
        return app.response_class(
            response=json.dumps(response_data, cls=NumpyEncoder),
            status=200,
            mimetype='application/json'
        )
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"An error occurred during file analysis: {str(e)}", exc_info=True)
        return jsonify({'error': f"An error occurred: {str(e)}"}), 500
 
# Add this to your Flask app configuration
app.json_encoder = NumpyEncoder
 
@app.route('/api/admin/stats', methods=['GET'])
@jwt_required()
def get_admin_stats():
    current_user = User.query.filter_by(username=get_jwt_identity()).first()
    if not current_user.is_admin:
        app.logger.warning(f"Non-admin user {current_user.username} attempted to access admin stats")
        return jsonify({"msg": "Admin access required"}), 403
 
    total_users = User.query.count()
    files_analyzed = UploadedFile.query.count()
    malware_detected = AnalysisResult.query.filter(AnalysisResult.binary_class != 'benign').count()
 
    app.logger.info(f"Admin stats accessed by {current_user.username}")
    return jsonify({
        'totalUsers': total_users,
        'filesAnalyzed': files_analyzed,
        'malwareDetected': malware_detected
    })
 
def create_admin_user():
    with app.app_context():
        admin_user = User.query.filter_by(username='admin').first()
        if not admin_user:
            admin_user = User(username='admin', password=generate_password_hash('admin_password'), is_admin=True)
            db.session.add(admin_user)
            db.session.commit()
            app.logger.info("Admin user created.")
        else:
            app.logger.info("Admin user already exists.")
 
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create database tables
        create_admin_user()  # Create admin user if it doesn't exist
    app.run(debug=True)