document.addEventListener("DOMContentLoaded", function () {
    // Initialize Pie Chart
    var pieChart = echarts.init(document.getElementById('user-pie-chart'));
    var pieOption = {
        title: {
            text: 'User-Specific Malware Detection',
            left: 'center'
        },
        tooltip: {
            trigger: 'item'
        },
        legend: {
            orient: 'vertical',
            left: 'left'
        },
        series: [
            {
                name: 'Malware Types',
                type: 'pie',
                radius: '50%',
                data: [
                    { value: 335, name: 'Benign' },
                    { value: 234, name: 'Malware' },
                    { value: 135, name: 'Phishing' },
                    { value: 1548, name: 'Defacement' }
                ],
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };
    pieChart.setOption(pieOption);

    // Initialize Bar Chart
    var barChart = echarts.init(document.getElementById('user-bar-chart'));
    var barOption = {
        title: {
            text: 'User Attack Logs',
            left: 'center'
        },
        xAxis: {
            type: 'category',
            data: ['Attack 1', 'Attack 2', 'Attack 3', 'Attack 4']
        },
        yAxis: {
            type: 'value'
        },
        series: [{
            data: [100, 80, 120, 90],
            type: 'bar'
        }]
    };
    barChart.setOption(barOption);
});
