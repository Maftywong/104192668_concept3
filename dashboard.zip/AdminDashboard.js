document.addEventListener("DOMContentLoaded", function () {
  // Initialize Pie Chart
  var pieChart = echarts.init(document.getElementById('admin-pie-chart'));
  var pieOption = {
      title: {
          text: 'Malware Distribution',
          left: 'center'
      },
      tooltip: {
          trigger: 'item'
      },
      legend: {
          orient: 'vertical',
          left: 'left'
      },
      series: [
          {
              name: 'Malware Types',
              type: 'pie',
              radius: '50%',
              data: [
                  { value: 1048, name: 'Malware Type A' },
                  { value: 735, name: 'Malware Type B' },
                  { value: 580, name: 'Malware Type C' },
                  { value: 484, name: 'Malware Type D' },
                  { value: 300, name: 'Malware Type E' }
              ],
              emphasis: {
                  itemStyle: {
                      shadowBlur: 10,
                      shadowOffsetX: 0,
                      shadowColor: 'rgba(0, 0, 0, 0.5)'
                  }
              }
          }
      ]
  };
  pieChart.setOption(pieOption);

  // Initialize Bar Chart
  var barChart = echarts.init(document.getElementById('admin-bar-chart'));
  var barOption = {
      title: {
          text: 'Attack Count Over Time',
          left: 'center'
      },
      xAxis: {
          type: 'category',
          data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
      },
      yAxis: {
          type: 'value'
      },
      series: [{
          data: [120, 200, 150, 80, 70, 110],
          type: 'bar'
      }]
  };
  barChart.setOption(barOption);
});
